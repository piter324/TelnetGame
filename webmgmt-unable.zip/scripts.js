let webSocket = null;

function connectToServer(){
    const addr = document.getElementById('addr');
    const port = document.getElementById('port');
        
    const output = document.getElementById('output');

    webSocket = new WebSocket(`ws://${addr.value}:${port.value}`);
    webSocket.onopen = (event) => {
        console.log("Connection is open");
    }

    webSocket.onmessage = (event) => {
        console.log(event);
        output.value += event.data+'\n';
    }
}

function sendMessage(){
    const command = document.getElementById('command');
    webSocket.send(command.value);
}